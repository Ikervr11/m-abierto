# Open World Realistic — prototipo web

Prototipo 3D de exploración en tercera persona para publicar en GitHub Pages.

## Cómo ejecutarlo

1. Sube `index.html` a la raíz de un repositorio de GitHub.
2. En Settings → Pages, elige **Deploy from a branch**, rama `main`, carpeta `/(root)`.
3. Abre la URL que GitHub Pages muestre.

El motor Three.js se carga desde jsDelivr y el prototipo intenta cargar un modelo de ejemplo de Three.js. Hace falta conexión a Internet. Si el modelo remoto no se carga, queda un personaje provisional articulado completo como alternativa.

## Controles

- W/A/S/D o flechas: moverse
- Ratón: mirar
- Shift: correr
- Esc: liberar el ratón

## Nota sobre los recursos

La geometría del entorno y el personaje de reserva se generan en código. El modelo remoto de muestra procede del repositorio de ejemplos de Three.js; consulta las licencias y condiciones de los recursos de terceros antes de redistribuir una versión comercial. Este prototipo no es un clon de GTA ni alcanza aún su calidad gráfica.
